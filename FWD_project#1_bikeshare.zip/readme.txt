This project is about exploring bike share dataset for 3 cities [Chicago, New York City, and Washington].



I uesed some online websites to help me understand more about the methods of pandas, that I should use in this project like 
(GeeksforGeeks , W3Schools).


For the errors that I faced in this project I used stackoverflow and searched using quora too, to find how to solve these errors 
and it helps me alot through the projct.

i used the code form that was provided in work place of the website of udacity and it helps me to make my code more organized.

and thank you.